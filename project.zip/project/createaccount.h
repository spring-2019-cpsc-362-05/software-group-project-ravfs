#ifndef CREATEACCOUNT_H
#define CREATEACCOUNT_H

#include <QWidget>

namespace Ui {
class createAccount;
}

class createAccount : public QWidget
{
    Q_OBJECT

public:
    explicit createAccount(QWidget *parent = nullptr);
    ~createAccount();

private:
    Ui::createAccount *ui;
};

#endif // CREATEACCOUNT_H
