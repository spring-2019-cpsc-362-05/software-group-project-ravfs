# Req'd Services

Google Drive Folder Link: https://docs.google.com/document/d/17Vwq2--E2E2owvVAu1F1b5JE1MNuO3LW6uaz7Tk72Ak/edit?usp=sharing


Email Address

Samantha Montoya     sammontoya@csu.fullerton.edu

Rene Ortiz           ror5446@csu.fullerton.edu

Anthony Goossens     yorkii@csu.fullerton.edu

Francisco Daniel     fpdaniel2@csu.fullerton.edu

Vincent Bravinder    bravinderv@csu.fullerton.edu


