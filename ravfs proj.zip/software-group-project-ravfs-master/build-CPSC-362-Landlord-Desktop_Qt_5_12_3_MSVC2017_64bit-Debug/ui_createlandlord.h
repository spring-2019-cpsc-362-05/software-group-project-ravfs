/********************************************************************************
** Form generated from reading UI file 'createlandlord.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATELANDLORD_H
#define UI_CREATELANDLORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_createLandlord
{
public:
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QLineEdit *locationKeyTextBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *locationAddressTextBox;
    QPushButton *enterButton;
    QPushButton *registerButton;

    void setupUi(QWidget *createLandlord)
    {
        if (createLandlord->objectName().isEmpty())
            createLandlord->setObjectName(QString::fromUtf8("createLandlord"));
        createLandlord->resize(687, 270);
        radioButton = new QRadioButton(createLandlord);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(100, 40, 131, 20));
        radioButton->setChecked(true);
        radioButton_2 = new QRadioButton(createLandlord);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(440, 40, 95, 20));
        locationKeyTextBox = new QLineEdit(createLandlord);
        locationKeyTextBox->setObjectName(QString::fromUtf8("locationKeyTextBox"));
        locationKeyTextBox->setGeometry(QRect(110, 120, 113, 22));
        label = new QLabel(createLandlord);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 80, 121, 16));
        label_2 = new QLabel(createLandlord);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(420, 80, 131, 16));
        locationAddressTextBox = new QLineEdit(createLandlord);
        locationAddressTextBox->setObjectName(QString::fromUtf8("locationAddressTextBox"));
        locationAddressTextBox->setEnabled(false);
        locationAddressTextBox->setGeometry(QRect(370, 120, 251, 22));
        enterButton = new QPushButton(createLandlord);
        enterButton->setObjectName(QString::fromUtf8("enterButton"));
        enterButton->setGeometry(QRect(120, 180, 93, 28));
        registerButton = new QPushButton(createLandlord);
        registerButton->setObjectName(QString::fromUtf8("registerButton"));
        registerButton->setEnabled(false);
        registerButton->setGeometry(QRect(440, 180, 93, 28));

        retranslateUi(createLandlord);

        QMetaObject::connectSlotsByName(createLandlord);
    } // setupUi

    void retranslateUi(QWidget *createLandlord)
    {
        createLandlord->setWindowTitle(QApplication::translate("createLandlord", "Form", nullptr));
        radioButton->setText(QApplication::translate("createLandlord", "Existing location", nullptr));
        radioButton_2->setText(QApplication::translate("createLandlord", "new location", nullptr));
        label->setText(QApplication::translate("createLandlord", "Enter location key:", nullptr));
        label_2->setText(QApplication::translate("createLandlord", "Enter location Address:", nullptr));
        enterButton->setText(QApplication::translate("createLandlord", "Enter", nullptr));
        registerButton->setText(QApplication::translate("createLandlord", "Register", nullptr));
    } // retranslateUi

};

namespace Ui {
    class createLandlord: public Ui_createLandlord {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATELANDLORD_H
