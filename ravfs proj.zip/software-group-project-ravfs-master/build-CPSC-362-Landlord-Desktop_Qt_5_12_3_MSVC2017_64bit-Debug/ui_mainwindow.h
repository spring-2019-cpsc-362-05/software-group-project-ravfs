/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_5;
    QStackedWidget *stackedWidget;
    QWidget *page_sign_in;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit_username;
    QLabel *label_2;
    QLineEdit *lineEdit_password;
    QLabel *label_pass_incorrect;
    QPushButton *pushButton_sign_in;
    QPushButton *pushButton_create_account;
    QWidget *page_tenant;
    QVBoxLayout *verticalLayout_6;
    QTabWidget *Tenant_tabs;
    QWidget *Tenant_view_requests_tab;
    QWidget *Tenant_request_service_tab;
    QWidget *Tenant_acct_settings_tab;
    QWidget *page_landlord;
    QVBoxLayout *verticalLayout_4;
    QTabWidget *Landlord_tabs;
    QWidget *Landlord_Requests_tab;
    QWidget *Landlord_view_tenants_tab;
    QWidget *Landlord_serv_prov_tab;
    QWidget *Landlord_acct_settings_tab;
    QWidget *page_service_provider;
    QVBoxLayout *verticalLayout_7;
    QTabWidget *tabWidget;
    QWidget *Serv_prov_requests_tab;
    QWidget *Serv_prov_claims_tab;
    QWidget *Serv_prov_acct_settings_tab;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(966, 413);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout_5 = new QVBoxLayout(centralWidget);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        page_sign_in = new QWidget();
        page_sign_in->setObjectName(QString::fromUtf8("page_sign_in"));
        verticalLayout_3 = new QVBoxLayout(page_sign_in);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        groupBox = new QGroupBox(page_sign_in);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout_2 = new QVBoxLayout(groupBox);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        verticalLayout_2->addWidget(label);

        lineEdit_username = new QLineEdit(groupBox);
        lineEdit_username->setObjectName(QString::fromUtf8("lineEdit_username"));

        verticalLayout_2->addWidget(lineEdit_username);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignBottom|Qt::AlignHCenter);

        verticalLayout_2->addWidget(label_2);

        lineEdit_password = new QLineEdit(groupBox);
        lineEdit_password->setObjectName(QString::fromUtf8("lineEdit_password"));

        verticalLayout_2->addWidget(lineEdit_password);

        label_pass_incorrect = new QLabel(groupBox);
        label_pass_incorrect->setObjectName(QString::fromUtf8("label_pass_incorrect"));
        label_pass_incorrect->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_pass_incorrect);

        pushButton_sign_in = new QPushButton(groupBox);
        pushButton_sign_in->setObjectName(QString::fromUtf8("pushButton_sign_in"));

        verticalLayout_2->addWidget(pushButton_sign_in);

        pushButton_create_account = new QPushButton(groupBox);
        pushButton_create_account->setObjectName(QString::fromUtf8("pushButton_create_account"));

        verticalLayout_2->addWidget(pushButton_create_account);

        pushButton_create_account->raise();
        label->raise();
        lineEdit_username->raise();
        label_2->raise();
        lineEdit_password->raise();
        label_pass_incorrect->raise();
        pushButton_sign_in->raise();

        verticalLayout_3->addWidget(groupBox);

        stackedWidget->addWidget(page_sign_in);
        page_tenant = new QWidget();
        page_tenant->setObjectName(QString::fromUtf8("page_tenant"));
        verticalLayout_6 = new QVBoxLayout(page_tenant);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        Tenant_tabs = new QTabWidget(page_tenant);
        Tenant_tabs->setObjectName(QString::fromUtf8("Tenant_tabs"));
        Tenant_view_requests_tab = new QWidget();
        Tenant_view_requests_tab->setObjectName(QString::fromUtf8("Tenant_view_requests_tab"));
        Tenant_tabs->addTab(Tenant_view_requests_tab, QString());
        Tenant_request_service_tab = new QWidget();
        Tenant_request_service_tab->setObjectName(QString::fromUtf8("Tenant_request_service_tab"));
        Tenant_tabs->addTab(Tenant_request_service_tab, QString());
        Tenant_acct_settings_tab = new QWidget();
        Tenant_acct_settings_tab->setObjectName(QString::fromUtf8("Tenant_acct_settings_tab"));
        Tenant_tabs->addTab(Tenant_acct_settings_tab, QString());

        verticalLayout_6->addWidget(Tenant_tabs);

        stackedWidget->addWidget(page_tenant);
        page_landlord = new QWidget();
        page_landlord->setObjectName(QString::fromUtf8("page_landlord"));
        verticalLayout_4 = new QVBoxLayout(page_landlord);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        Landlord_tabs = new QTabWidget(page_landlord);
        Landlord_tabs->setObjectName(QString::fromUtf8("Landlord_tabs"));
        Landlord_Requests_tab = new QWidget();
        Landlord_Requests_tab->setObjectName(QString::fromUtf8("Landlord_Requests_tab"));
        Landlord_tabs->addTab(Landlord_Requests_tab, QString());
        Landlord_view_tenants_tab = new QWidget();
        Landlord_view_tenants_tab->setObjectName(QString::fromUtf8("Landlord_view_tenants_tab"));
        Landlord_tabs->addTab(Landlord_view_tenants_tab, QString());
        Landlord_serv_prov_tab = new QWidget();
        Landlord_serv_prov_tab->setObjectName(QString::fromUtf8("Landlord_serv_prov_tab"));
        Landlord_tabs->addTab(Landlord_serv_prov_tab, QString());
        Landlord_acct_settings_tab = new QWidget();
        Landlord_acct_settings_tab->setObjectName(QString::fromUtf8("Landlord_acct_settings_tab"));
        Landlord_tabs->addTab(Landlord_acct_settings_tab, QString());

        verticalLayout_4->addWidget(Landlord_tabs);

        stackedWidget->addWidget(page_landlord);
        page_service_provider = new QWidget();
        page_service_provider->setObjectName(QString::fromUtf8("page_service_provider"));
        verticalLayout_7 = new QVBoxLayout(page_service_provider);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        tabWidget = new QTabWidget(page_service_provider);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        Serv_prov_requests_tab = new QWidget();
        Serv_prov_requests_tab->setObjectName(QString::fromUtf8("Serv_prov_requests_tab"));
        tabWidget->addTab(Serv_prov_requests_tab, QString());
        Serv_prov_claims_tab = new QWidget();
        Serv_prov_claims_tab->setObjectName(QString::fromUtf8("Serv_prov_claims_tab"));
        tabWidget->addTab(Serv_prov_claims_tab, QString());
        Serv_prov_acct_settings_tab = new QWidget();
        Serv_prov_acct_settings_tab->setObjectName(QString::fromUtf8("Serv_prov_acct_settings_tab"));
        tabWidget->addTab(Serv_prov_acct_settings_tab, QString());

        verticalLayout_7->addWidget(tabWidget);

        stackedWidget->addWidget(page_service_provider);

        verticalLayout_5->addWidget(stackedWidget);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 966, 26));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);
        Tenant_tabs->setCurrentIndex(0);
        Landlord_tabs->setCurrentIndex(3);
        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Sign In", nullptr));
        groupBox->setTitle(QString());
        label->setText(QApplication::translate("MainWindow", "Email", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Password", nullptr));
        label_pass_incorrect->setText(QString());
        pushButton_sign_in->setText(QApplication::translate("MainWindow", "Sign In", nullptr));
        pushButton_create_account->setText(QApplication::translate("MainWindow", "Create Account", nullptr));
        Tenant_tabs->setTabText(Tenant_tabs->indexOf(Tenant_view_requests_tab), QApplication::translate("MainWindow", "View Requests", nullptr));
        Tenant_tabs->setTabText(Tenant_tabs->indexOf(Tenant_request_service_tab), QApplication::translate("MainWindow", "Request Service", nullptr));
        Tenant_tabs->setTabText(Tenant_tabs->indexOf(Tenant_acct_settings_tab), QApplication::translate("MainWindow", "Account Settings", nullptr));
        Landlord_tabs->setTabText(Landlord_tabs->indexOf(Landlord_Requests_tab), QApplication::translate("MainWindow", "Requests", nullptr));
        Landlord_tabs->setTabText(Landlord_tabs->indexOf(Landlord_view_tenants_tab), QApplication::translate("MainWindow", "Tenants", nullptr));
        Landlord_tabs->setTabText(Landlord_tabs->indexOf(Landlord_serv_prov_tab), QApplication::translate("MainWindow", "Service Providers", nullptr));
        Landlord_tabs->setTabText(Landlord_tabs->indexOf(Landlord_acct_settings_tab), QApplication::translate("MainWindow", "Account Settings", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Serv_prov_requests_tab), QApplication::translate("MainWindow", "Requests", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Serv_prov_claims_tab), QApplication::translate("MainWindow", "Claims", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(Serv_prov_acct_settings_tab), QApplication::translate("MainWindow", "Account Settings", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
