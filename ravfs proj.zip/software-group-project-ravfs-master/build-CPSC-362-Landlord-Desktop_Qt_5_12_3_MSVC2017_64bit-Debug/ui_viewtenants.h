/********************************************************************************
** Form generated from reading UI file 'viewtenants.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWTENANTS_H
#define UI_VIEWTENANTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_viewTenants
{
public:
    QTableView *tableView;

    void setupUi(QWidget *viewTenants)
    {
        if (viewTenants->objectName().isEmpty())
            viewTenants->setObjectName(QString::fromUtf8("viewTenants"));
        viewTenants->resize(628, 447);
        tableView = new QTableView(viewTenants);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(50, 30, 521, 351));

        retranslateUi(viewTenants);

        QMetaObject::connectSlotsByName(viewTenants);
    } // setupUi

    void retranslateUi(QWidget *viewTenants)
    {
        viewTenants->setWindowTitle(QApplication::translate("viewTenants", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class viewTenants: public Ui_viewTenants {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWTENANTS_H
