/********************************************************************************
** Form generated from reading UI file 'createaccount.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATEACCOUNT_H
#define UI_CREATEACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_createAccount
{
public:
    QLineEdit *lineEdit_firstName;
    QLineEdit *lineEdit_lastName;
    QLineEdit *lineEdit_password;
    QLineEdit *lineEdit_email;
    QLineEdit *lineEdit_address;
    QLineEdit *lineEdit_phoneNumber;
    QRadioButton *spButton;
    QRadioButton *landlordButton;
    QRadioButton *tenantButton;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEdit_lEmail;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QLineEdit *lineEdit_locationKey;
    QLineEdit *lineEdit_locationAddress;
    QLineEdit *lineEdit_websiteLink;
    QLineEdit *lineEdit_normalHours;
    QLineEdit *lineEdit_emergencyHours;
    QLineEdit *lineEdit_hourlyRate;
    QLineEdit *lineEdit_baseRate;
    QTextEdit *textEdit_servicesProvided;

    void setupUi(QWidget *createAccount)
    {
        if (createAccount->objectName().isEmpty())
            createAccount->setObjectName(QString::fromUtf8("createAccount"));
        createAccount->resize(1039, 596);
        lineEdit_firstName = new QLineEdit(createAccount);
        lineEdit_firstName->setObjectName(QString::fromUtf8("lineEdit_firstName"));
        lineEdit_firstName->setGeometry(QRect(182, 60, 191, 22));
        lineEdit_lastName = new QLineEdit(createAccount);
        lineEdit_lastName->setObjectName(QString::fromUtf8("lineEdit_lastName"));
        lineEdit_lastName->setGeometry(QRect(182, 100, 191, 22));
        lineEdit_password = new QLineEdit(createAccount);
        lineEdit_password->setObjectName(QString::fromUtf8("lineEdit_password"));
        lineEdit_password->setGeometry(QRect(182, 190, 191, 22));
        lineEdit_email = new QLineEdit(createAccount);
        lineEdit_email->setObjectName(QString::fromUtf8("lineEdit_email"));
        lineEdit_email->setGeometry(QRect(182, 140, 191, 22));
        lineEdit_address = new QLineEdit(createAccount);
        lineEdit_address->setObjectName(QString::fromUtf8("lineEdit_address"));
        lineEdit_address->setGeometry(QRect(182, 230, 191, 22));
        lineEdit_phoneNumber = new QLineEdit(createAccount);
        lineEdit_phoneNumber->setObjectName(QString::fromUtf8("lineEdit_phoneNumber"));
        lineEdit_phoneNumber->setGeometry(QRect(182, 270, 191, 22));
        spButton = new QRadioButton(createAccount);
        spButton->setObjectName(QString::fromUtf8("spButton"));
        spButton->setGeometry(QRect(740, 20, 141, 20));
        landlordButton = new QRadioButton(createAccount);
        landlordButton->setObjectName(QString::fromUtf8("landlordButton"));
        landlordButton->setGeometry(QRect(460, 160, 95, 20));
        tenantButton = new QRadioButton(createAccount);
        tenantButton->setObjectName(QString::fromUtf8("tenantButton"));
        tenantButton->setGeometry(QRect(470, 20, 95, 20));
        tenantButton->setChecked(true);
        pushButton = new QPushButton(createAccount);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(860, 480, 111, 28));
        label = new QLabel(createAccount);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 60, 121, 20));
        label_2 = new QLabel(createAccount);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 100, 121, 20));
        label_3 = new QLabel(createAccount);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 140, 121, 20));
        label_4 = new QLabel(createAccount);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 270, 121, 20));
        label_5 = new QLabel(createAccount);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 230, 121, 20));
        label_6 = new QLabel(createAccount);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 190, 121, 20));
        label_7 = new QLabel(createAccount);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(420, 40, 161, 41));
        lineEdit_lEmail = new QLineEdit(createAccount);
        lineEdit_lEmail->setObjectName(QString::fromUtf8("lineEdit_lEmail"));
        lineEdit_lEmail->setGeometry(QRect(410, 90, 191, 22));
        label_8 = new QLabel(createAccount);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(310, 20, 121, 20));
        label_9 = new QLabel(createAccount);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(420, 190, 161, 20));
        label_10 = new QLabel(createAccount);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(420, 270, 121, 20));
        label_11 = new QLabel(createAccount);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(420, 300, 181, 20));
        label_12 = new QLabel(createAccount);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(650, 60, 121, 20));
        label_13 = new QLabel(createAccount);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(630, 100, 121, 20));
        label_14 = new QLabel(createAccount);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(620, 140, 141, 20));
        label_15 = new QLabel(createAccount);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(630, 190, 121, 20));
        label_16 = new QLabel(createAccount);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(620, 240, 121, 20));
        label_17 = new QLabel(createAccount);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(620, 280, 121, 20));
        lineEdit_locationKey = new QLineEdit(createAccount);
        lineEdit_locationKey->setObjectName(QString::fromUtf8("lineEdit_locationKey"));
        lineEdit_locationKey->setGeometry(QRect(410, 230, 191, 22));
        lineEdit_locationAddress = new QLineEdit(createAccount);
        lineEdit_locationAddress->setObjectName(QString::fromUtf8("lineEdit_locationAddress"));
        lineEdit_locationAddress->setGeometry(QRect(410, 350, 191, 22));
        lineEdit_websiteLink = new QLineEdit(createAccount);
        lineEdit_websiteLink->setObjectName(QString::fromUtf8("lineEdit_websiteLink"));
        lineEdit_websiteLink->setGeometry(QRect(800, 60, 231, 22));
        lineEdit_normalHours = new QLineEdit(createAccount);
        lineEdit_normalHours->setObjectName(QString::fromUtf8("lineEdit_normalHours"));
        lineEdit_normalHours->setGeometry(QRect(800, 100, 231, 22));
        lineEdit_emergencyHours = new QLineEdit(createAccount);
        lineEdit_emergencyHours->setObjectName(QString::fromUtf8("lineEdit_emergencyHours"));
        lineEdit_emergencyHours->setGeometry(QRect(800, 150, 231, 22));
        lineEdit_hourlyRate = new QLineEdit(createAccount);
        lineEdit_hourlyRate->setObjectName(QString::fromUtf8("lineEdit_hourlyRate"));
        lineEdit_hourlyRate->setGeometry(QRect(800, 190, 231, 22));
        lineEdit_baseRate = new QLineEdit(createAccount);
        lineEdit_baseRate->setObjectName(QString::fromUtf8("lineEdit_baseRate"));
        lineEdit_baseRate->setGeometry(QRect(800, 240, 231, 22));
        textEdit_servicesProvided = new QTextEdit(createAccount);
        textEdit_servicesProvided->setObjectName(QString::fromUtf8("textEdit_servicesProvided"));
        textEdit_servicesProvided->setGeometry(QRect(800, 290, 231, 151));

        retranslateUi(createAccount);

        QMetaObject::connectSlotsByName(createAccount);
    } // setupUi

    void retranslateUi(QWidget *createAccount)
    {
        createAccount->setWindowTitle(QApplication::translate("createAccount", "Form", nullptr));
        spButton->setText(QApplication::translate("createAccount", "Service Provider", nullptr));
        landlordButton->setText(QApplication::translate("createAccount", "Landlord", nullptr));
        tenantButton->setText(QApplication::translate("createAccount", "Tenant", nullptr));
        pushButton->setText(QApplication::translate("createAccount", "Create Account", nullptr));
        label->setText(QApplication::translate("createAccount", "First Name:", nullptr));
        label_2->setText(QApplication::translate("createAccount", "Last name:", nullptr));
        label_3->setText(QApplication::translate("createAccount", "Email:", nullptr));
        label_4->setText(QApplication::translate("createAccount", "Phone Number:", nullptr));
        label_5->setText(QApplication::translate("createAccount", "Address", nullptr));
        label_6->setText(QApplication::translate("createAccount", "Password:", nullptr));
        label_7->setText(QApplication::translate("createAccount", "Enter your landlord's Email:", nullptr));
        label_8->setText(QApplication::translate("createAccount", "Account type:", nullptr));
        label_9->setText(QApplication::translate("createAccount", "Enter existing location key:", nullptr));
        label_10->setText(QApplication::translate("createAccount", "or", nullptr));
        label_11->setText(QApplication::translate("createAccount", "Enter a new locations address", nullptr));
        label_12->setText(QApplication::translate("createAccount", "Enter website link:", nullptr));
        label_13->setText(QApplication::translate("createAccount", "Enter normal hours:", nullptr));
        label_14->setText(QApplication::translate("createAccount", "Enter emergency hours:", nullptr));
        label_15->setText(QApplication::translate("createAccount", "Enter hourly rate in $:", nullptr));
        label_16->setText(QApplication::translate("createAccount", "Enter base rate in $", nullptr));
        label_17->setText(QApplication::translate("createAccount", "list services provided", nullptr));
    } // retranslateUi

};

namespace Ui {
    class createAccount: public Ui_createAccount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATEACCOUNT_H
