/********************************************************************************
** Form generated from reading UI file 'mainmenu.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINMENU_H
#define UI_MAINMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mainMenu
{
public:
    QPushButton *pushButton_createReq;
    QPushButton *pushButton_viewReq;
    QPushButton *pushButton_viewTenants;
    QPushButton *pushButton_viewClaims;
    QPushButton *pushButton_acctSettings;

    void setupUi(QWidget *mainMenu)
    {
        if (mainMenu->objectName().isEmpty())
            mainMenu->setObjectName(QString::fromUtf8("mainMenu"));
        mainMenu->resize(571, 423);
        pushButton_createReq = new QPushButton(mainMenu);
        pushButton_createReq->setObjectName(QString::fromUtf8("pushButton_createReq"));
        pushButton_createReq->setGeometry(QRect(102, 40, 341, 51));
        pushButton_viewReq = new QPushButton(mainMenu);
        pushButton_viewReq->setObjectName(QString::fromUtf8("pushButton_viewReq"));
        pushButton_viewReq->setGeometry(QRect(100, 110, 341, 51));
        pushButton_viewTenants = new QPushButton(mainMenu);
        pushButton_viewTenants->setObjectName(QString::fromUtf8("pushButton_viewTenants"));
        pushButton_viewTenants->setGeometry(QRect(100, 250, 341, 51));
        pushButton_viewClaims = new QPushButton(mainMenu);
        pushButton_viewClaims->setObjectName(QString::fromUtf8("pushButton_viewClaims"));
        pushButton_viewClaims->setGeometry(QRect(100, 180, 341, 51));
        pushButton_acctSettings = new QPushButton(mainMenu);
        pushButton_acctSettings->setObjectName(QString::fromUtf8("pushButton_acctSettings"));
        pushButton_acctSettings->setGeometry(QRect(100, 320, 341, 51));

        retranslateUi(mainMenu);

        QMetaObject::connectSlotsByName(mainMenu);
    } // setupUi

    void retranslateUi(QWidget *mainMenu)
    {
        mainMenu->setWindowTitle(QApplication::translate("mainMenu", "Form", nullptr));
        pushButton_createReq->setText(QApplication::translate("mainMenu", "Create Request", nullptr));
        pushButton_viewReq->setText(QApplication::translate("mainMenu", "View Requests", nullptr));
        pushButton_viewTenants->setText(QApplication::translate("mainMenu", "View Tenants", nullptr));
        pushButton_viewClaims->setText(QApplication::translate("mainMenu", "View Claims", nullptr));
        pushButton_acctSettings->setText(QApplication::translate("mainMenu", "Account Settings", nullptr));
    } // retranslateUi

};

namespace Ui {
    class mainMenu: public Ui_mainMenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINMENU_H
