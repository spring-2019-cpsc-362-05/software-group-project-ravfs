/********************************************************************************
** Form generated from reading UI file 'createclaim.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATECLAIM_H
#define UI_CREATECLAIM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_createClaim
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QTextEdit *textEdit;
    QPushButton *pushButton;

    void setupUi(QWidget *createClaim)
    {
        if (createClaim->objectName().isEmpty())
            createClaim->setObjectName(QString::fromUtf8("createClaim"));
        createClaim->resize(400, 300);
        label = new QLabel(createClaim);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(84, 20, 101, 20));
        label_2 = new QLabel(createClaim);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(74, 60, 81, 20));
        label_3 = new QLabel(createClaim);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(64, 100, 91, 20));
        lineEdit_2 = new QLineEdit(createClaim);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(190, 60, 161, 22));
        textEdit = new QTextEdit(createClaim);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(163, 100, 201, 141));
        pushButton = new QPushButton(createClaim);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(260, 260, 93, 28));

        retranslateUi(createClaim);

        QMetaObject::connectSlotsByName(createClaim);
    } // setupUi

    void retranslateUi(QWidget *createClaim)
    {
        createClaim->setWindowTitle(QApplication::translate("createClaim", "Form", nullptr));
        label->setText(QApplication::translate("createClaim", "Request ID:", nullptr));
        label_2->setText(QApplication::translate("createClaim", "Complete By", nullptr));
        label_3->setText(QApplication::translate("createClaim", "invoice:", nullptr));
        pushButton->setText(QApplication::translate("createClaim", "Create Claim", nullptr));
    } // retranslateUi

};

namespace Ui {
    class createClaim: public Ui_createClaim {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATECLAIM_H
