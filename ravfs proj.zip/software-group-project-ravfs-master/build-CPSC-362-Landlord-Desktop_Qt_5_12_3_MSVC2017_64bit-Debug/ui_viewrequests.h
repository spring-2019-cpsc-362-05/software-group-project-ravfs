/********************************************************************************
** Form generated from reading UI file 'viewrequests.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWREQUESTS_H
#define UI_VIEWREQUESTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_viewRequests
{
public:
    QTableView *tableView;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLabel *label;
    QPushButton *pushButton_3;

    void setupUi(QWidget *viewRequests)
    {
        if (viewRequests->objectName().isEmpty())
            viewRequests->setObjectName(QString::fromUtf8("viewRequests"));
        viewRequests->resize(871, 486);
        tableView = new QTableView(viewRequests);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(35, 30, 811, 291));
        pushButton = new QPushButton(viewRequests);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(700, 410, 111, 41));
        lineEdit = new QLineEdit(viewRequests);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(700, 370, 113, 22));
        label = new QLabel(viewRequests);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(610, 370, 71, 16));
        pushButton_3 = new QPushButton(viewRequests);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(510, 410, 111, 41));

        retranslateUi(viewRequests);

        QMetaObject::connectSlotsByName(viewRequests);
    } // setupUi

    void retranslateUi(QWidget *viewRequests)
    {
        viewRequests->setWindowTitle(QApplication::translate("viewRequests", "Form", nullptr));
        pushButton->setText(QApplication::translate("viewRequests", "Edit Request", nullptr));
        label->setText(QApplication::translate("viewRequests", "Request ID", nullptr));
        pushButton_3->setText(QApplication::translate("viewRequests", "Refresh", nullptr));
    } // retranslateUi

};

namespace Ui {
    class viewRequests: public Ui_viewRequests {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWREQUESTS_H
