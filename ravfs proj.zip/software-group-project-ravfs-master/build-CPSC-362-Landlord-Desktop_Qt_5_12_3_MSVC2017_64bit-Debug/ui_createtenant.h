/********************************************************************************
** Form generated from reading UI file 'createtenant.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATETENANT_H
#define UI_CREATETENANT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_createTenant
{
public:
    QLabel *label;
    QLineEdit *lineEdit;
    QPushButton *pushButton;

    void setupUi(QWidget *createTenant)
    {
        if (createTenant->objectName().isEmpty())
            createTenant->setObjectName(QString::fromUtf8("createTenant"));
        createTenant->resize(492, 248);
        label = new QLabel(createTenant);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 80, 161, 31));
        lineEdit = new QLineEdit(createTenant);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(220, 90, 221, 22));
        pushButton = new QPushButton(createTenant);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(310, 150, 93, 28));

        retranslateUi(createTenant);

        QMetaObject::connectSlotsByName(createTenant);
    } // setupUi

    void retranslateUi(QWidget *createTenant)
    {
        createTenant->setWindowTitle(QApplication::translate("createTenant", "Form", nullptr));
        label->setText(QApplication::translate("createTenant", "Enter your landlord's email", nullptr));
        pushButton->setText(QApplication::translate("createTenant", "Enter", nullptr));
    } // retranslateUi

};

namespace Ui {
    class createTenant: public Ui_createTenant {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATETENANT_H
