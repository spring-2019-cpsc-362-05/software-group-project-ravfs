/********************************************************************************
** Form generated from reading UI file 'viewclaims.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWCLAIMS_H
#define UI_VIEWCLAIMS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_viewClaims
{
public:
    QTableView *tableView;
    QPushButton *pushButton_pay;
    QLineEdit *lineEdit;
    QLabel *label;

    void setupUi(QWidget *viewClaims)
    {
        if (viewClaims->objectName().isEmpty())
            viewClaims->setObjectName(QString::fromUtf8("viewClaims"));
        viewClaims->resize(604, 478);
        tableView = new QTableView(viewClaims);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(50, 40, 501, 291));
        pushButton_pay = new QPushButton(viewClaims);
        pushButton_pay->setObjectName(QString::fromUtf8("pushButton_pay"));
        pushButton_pay->setGeometry(QRect(410, 390, 131, 41));
        lineEdit = new QLineEdit(viewClaims);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(270, 400, 113, 21));
        label = new QLabel(viewClaims);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(280, 370, 91, 16));

        retranslateUi(viewClaims);

        QMetaObject::connectSlotsByName(viewClaims);
    } // setupUi

    void retranslateUi(QWidget *viewClaims)
    {
        viewClaims->setWindowTitle(QApplication::translate("viewClaims", "Form", nullptr));
        pushButton_pay->setText(QApplication::translate("viewClaims", "Mark Claim as  paid", nullptr));
        label->setText(QApplication::translate("viewClaims", "Enter Claim ID:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class viewClaims: public Ui_viewClaims {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWCLAIMS_H
