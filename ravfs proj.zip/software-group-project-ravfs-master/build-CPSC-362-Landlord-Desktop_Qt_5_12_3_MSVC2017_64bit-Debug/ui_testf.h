/********************************************************************************
** Form generated from reading UI file 'testf.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTF_H
#define UI_TESTF_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_testf
{
public:
    QPushButton *pushButton;
    QTableWidget *tableWidget;

    void setupUi(QWidget *testf)
    {
        if (testf->objectName().isEmpty())
            testf->setObjectName(QString::fromUtf8("testf"));
        testf->resize(400, 300);
        pushButton = new QPushButton(testf);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(240, 220, 93, 28));
        tableWidget = new QTableWidget(testf);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(110, 10, 256, 192));

        retranslateUi(testf);

        QMetaObject::connectSlotsByName(testf);
    } // setupUi

    void retranslateUi(QWidget *testf)
    {
        testf->setWindowTitle(QApplication::translate("testf", "Form", nullptr));
        pushButton->setText(QApplication::translate("testf", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class testf: public Ui_testf {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTF_H
