/********************************************************************************
** Form generated from reading UI file 'editrequest.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITREQUEST_H
#define UI_EDITREQUEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editRequest
{
public:
    QLabel *label;
    QLineEdit *lineEdit_kindOOfService;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_assignedProvider;
    QLabel *label_4;
    QLabel *label_5;
    QTextEdit *textEdit_notes;
    QLabel *label_6;
    QLabel *label_7;
    QTableView *tableViewt;
    QGroupBox *groupBox;
    QRadioButton *emergencyRadioButton;
    QRadioButton *noERadioButton;
    QGroupBox *groupBox_2;
    QRadioButton *payRadioButton;
    QRadioButton *noPayRadioButton;
    QPushButton *pushButton;

    void setupUi(QWidget *editRequest)
    {
        if (editRequest->objectName().isEmpty())
            editRequest->setObjectName(QString::fromUtf8("editRequest"));
        editRequest->resize(624, 950);
        label = new QLabel(editRequest);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 60, 81, 16));
        lineEdit_kindOOfService = new QLineEdit(editRequest);
        lineEdit_kindOOfService->setObjectName(QString::fromUtf8("lineEdit_kindOOfService"));
        lineEdit_kindOOfService->setGeometry(QRect(170, 100, 331, 22));
        label_2 = new QLabel(editRequest);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 100, 111, 16));
        label_3 = new QLabel(editRequest);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(50, 140, 141, 16));
        lineEdit_assignedProvider = new QLineEdit(editRequest);
        lineEdit_assignedProvider->setObjectName(QString::fromUtf8("lineEdit_assignedProvider"));
        lineEdit_assignedProvider->setGeometry(QRect(195, 370, 301, 22));
        label_4 = new QLabel(editRequest);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(15, 370, 161, 20));
        label_5 = new QLabel(editRequest);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(50, 180, 55, 16));
        textEdit_notes = new QTextEdit(editRequest);
        textEdit_notes->setObjectName(QString::fromUtf8("textEdit_notes"));
        textEdit_notes->setGeometry(QRect(180, 180, 181, 171));
        label_6 = new QLabel(editRequest);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(205, 410, 151, 16));
        label_7 = new QLabel(editRequest);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(210, 20, 161, 16));
        tableViewt = new QTableView(editRequest);
        tableViewt->setObjectName(QString::fromUtf8("tableViewt"));
        tableViewt->setGeometry(QRect(40, 450, 521, 371));
        groupBox = new QGroupBox(editRequest);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(160, 39, 321, 51));
        emergencyRadioButton = new QRadioButton(groupBox);
        emergencyRadioButton->setObjectName(QString::fromUtf8("emergencyRadioButton"));
        emergencyRadioButton->setGeometry(QRect(20, 20, 95, 20));
        noERadioButton = new QRadioButton(groupBox);
        noERadioButton->setObjectName(QString::fromUtf8("noERadioButton"));
        noERadioButton->setGeometry(QRect(150, 20, 95, 20));
        groupBox_2 = new QGroupBox(editRequest);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(170, 120, 321, 51));
        payRadioButton = new QRadioButton(groupBox_2);
        payRadioButton->setObjectName(QString::fromUtf8("payRadioButton"));
        payRadioButton->setGeometry(QRect(20, 20, 131, 20));
        noPayRadioButton = new QRadioButton(groupBox_2);
        noPayRadioButton->setObjectName(QString::fromUtf8("noPayRadioButton"));
        noPayRadioButton->setGeometry(QRect(160, 20, 151, 20));
        pushButton = new QPushButton(editRequest);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(370, 870, 141, 41));

        retranslateUi(editRequest);

        QMetaObject::connectSlotsByName(editRequest);
    } // setupUi

    void retranslateUi(QWidget *editRequest)
    {
        editRequest->setWindowTitle(QApplication::translate("editRequest", "Form", nullptr));
        label->setText(QApplication::translate("editRequest", "Emergency:", nullptr));
        label_2->setText(QApplication::translate("editRequest", "Kind of service:", nullptr));
        label_3->setText(QApplication::translate("editRequest", "Landlord status", nullptr));
        label_4->setText(QApplication::translate("editRequest", "Assigned Provider (email)", nullptr));
        label_5->setText(QApplication::translate("editRequest", "notes", nullptr));
        label_6->setText(QApplication::translate("editRequest", "List of Service Providers", nullptr));
        label_7->setText(QApplication::translate("editRequest", "Request ID : ", nullptr));
        groupBox->setTitle(QString());
        emergencyRadioButton->setText(QApplication::translate("editRequest", "Yes", nullptr));
        noERadioButton->setText(QApplication::translate("editRequest", "No", nullptr));
        groupBox_2->setTitle(QString());
        payRadioButton->setText(QApplication::translate("editRequest", "Landlord will pay", nullptr));
        noPayRadioButton->setText(QApplication::translate("editRequest", "Landlord will not pay", nullptr));
        pushButton->setText(QApplication::translate("editRequest", "Update", nullptr));
    } // retranslateUi

};

namespace Ui {
    class editRequest: public Ui_editRequest {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITREQUEST_H
