/********************************************************************************
** Form generated from reading UI file 'createrequest.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATEREQUEST_H
#define UI_CREATEREQUEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_createRequest
{
public:
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_kindOFService;
    QTextEdit *textEdit_notes;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QPushButton *pushButton;
    QLabel *label_3;
    QLineEdit *lineEdit_assignedProvider;
    QTableView *tableView;
    QLabel *label_4;

    void setupUi(QWidget *createRequest)
    {
        if (createRequest->objectName().isEmpty())
            createRequest->setObjectName(QString::fromUtf8("createRequest"));
        createRequest->resize(836, 499);
        label = new QLabel(createRequest);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(44, 40, 121, 20));
        label_2 = new QLabel(createRequest);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 90, 55, 16));
        lineEdit_kindOFService = new QLineEdit(createRequest);
        lineEdit_kindOFService->setObjectName(QString::fromUtf8("lineEdit_kindOFService"));
        lineEdit_kindOFService->setGeometry(QRect(192, 40, 251, 22));
        textEdit_notes = new QTextEdit(createRequest);
        textEdit_notes->setObjectName(QString::fromUtf8("textEdit_notes"));
        textEdit_notes->setGeometry(QRect(190, 90, 251, 121));
        radioButton = new QRadioButton(createRequest);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(190, 240, 95, 20));
        radioButton_2 = new QRadioButton(createRequest);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(320, 240, 131, 20));
        pushButton = new QPushButton(createRequest);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(230, 400, 141, 28));
        label_3 = new QLabel(createRequest);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 290, 141, 16));
        lineEdit_assignedProvider = new QLineEdit(createRequest);
        lineEdit_assignedProvider->setObjectName(QString::fromUtf8("lineEdit_assignedProvider"));
        lineEdit_assignedProvider->setGeometry(QRect(200, 290, 251, 22));
        tableView = new QTableView(createRequest);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(500, 80, 311, 371));
        label_4 = new QLabel(createRequest);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(580, 40, 141, 16));

        retranslateUi(createRequest);

        QMetaObject::connectSlotsByName(createRequest);
    } // setupUi

    void retranslateUi(QWidget *createRequest)
    {
        createRequest->setWindowTitle(QApplication::translate("createRequest", "Form", nullptr));
        label->setText(QApplication::translate("createRequest", "Service needed", nullptr));
        label_2->setText(QApplication::translate("createRequest", "Notes:", nullptr));
        radioButton->setText(QApplication::translate("createRequest", "Emergancy", nullptr));
        radioButton_2->setText(QApplication::translate("createRequest", "Non-Emergancy", nullptr));
        pushButton->setText(QApplication::translate("createRequest", "Submit Request", nullptr));
        label_3->setText(QApplication::translate("createRequest", "Assign provider (Email) :", nullptr));
        label_4->setText(QApplication::translate("createRequest", "List of Service Providers", nullptr));
    } // retranslateUi

};

namespace Ui {
    class createRequest: public Ui_createRequest {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATEREQUEST_H
